"use client";

import { useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  MessageSquare,
  ArrowLeft,
  Eye,
  EyeOff,
  Building2,
  User,
} from "lucide-react";

export default function LoginPage() {
  const [showPassword, setShowPassword] = useState(false);
  const [userType, setUserType] = useState<"worker" | "employer">("worker");

  return (
    <div className="min-h-screen bg-background flex">
      {/* Left side - Form */}
      <div className="flex-1 flex flex-col justify-center px-6 py-12 lg:px-8">
        <div className="sm:mx-auto sm:w-full sm:max-w-md">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-8"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to home
          </Link>

          <div className="flex items-center gap-2 mb-2">
            <div className="h-9 w-9 rounded-lg bg-foreground flex items-center justify-center">
              <MessageSquare className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-semibold tracking-tight">
              ShiftReady
            </span>
          </div>

          <h1 className="mt-8 text-3xl font-bold tracking-tight text-foreground">
            Welcome back
          </h1>
          <p className="mt-2 text-muted-foreground">
            Sign in to your account to continue
          </p>
        </div>

        <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
          {/* User type toggle */}
          <div className="flex gap-2 p-1 bg-muted rounded-lg mb-8">
            <button
              type="button"
              onClick={() => setUserType("worker")}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-md text-sm font-medium transition-all ${
                userType === "worker"
                  ? "bg-card text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <User className="h-4 w-4" />
              Worker
            </button>
            <button
              type="button"
              onClick={() => setUserType("employer")}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-md text-sm font-medium transition-all ${
                userType === "employer"
                  ? "bg-card text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Building2 className="h-4 w-4" />
              Employer
            </button>
          </div>

          <form className="space-y-6">
            <div>
              <Label htmlFor="email">
                {userType === "worker" ? "Phone number or email" : "Email"}
              </Label>
              <Input
                id="email"
                type={userType === "worker" ? "text" : "email"}
                placeholder={
                  userType === "worker"
                    ? "(210) 555-0123 or email@example.com"
                    : "you@company.com"
                }
                className="mt-2 bg-card"
              />
            </div>

            <div>
              <div className="flex items-center justify-between">
                <Label htmlFor="password">Password</Label>
                <Link
                  href="/forgot-password"
                  className="text-sm text-accent hover:underline"
                >
                  Forgot password?
                </Link>
              </div>
              <div className="relative mt-2">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="Enter your password"
                  className="bg-card pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4" />
                  ) : (
                    <Eye className="h-4 w-4" />
                  )}
                </button>
              </div>
            </div>

            <Button type="submit" className="w-full" size="lg">
              Sign in
            </Button>
          </form>

          <p className="mt-8 text-center text-sm text-muted-foreground">
            Don't have an account?{" "}
            <Link
              href={
                userType === "worker" ? "/signup/worker" : "/signup/employer"
              }
              className="text-accent font-medium hover:underline"
            >
              Sign up as {userType === "worker" ? "a worker" : "an employer"}
            </Link>
          </p>
        </div>
      </div>

      {/* Right side - Visual */}
      <div className="hidden lg:flex lg:flex-1 bg-foreground text-primary-foreground p-12 flex-col justify-between">
        <div />
        <div>
          <blockquote className="text-2xl font-medium leading-relaxed text-balance">
            "ShiftReady changed how I make extra money. I just reply YES to a
            text, show up, and get paid the same day. It's that simple."
          </blockquote>
          <div className="mt-8">
            <p className="font-semibold">Marcus J.</p>
            <p className="text-primary-foreground/70">
              ShiftReady Worker, San Antonio
            </p>
          </div>
        </div>
        <div className="flex items-center gap-8 text-sm text-primary-foreground/60">
          <div>
            <p className="text-3xl font-bold text-primary-foreground">500+</p>
            <p>Active Workers</p>
          </div>
          <div className="h-12 w-px bg-primary-foreground/20" />
          <div>
            <p className="text-3xl font-bold text-primary-foreground">50+</p>
            <p>Partner Employers</p>
          </div>
          <div className="h-12 w-px bg-primary-foreground/20" />
          <div>
            <p className="text-3xl font-bold text-primary-foreground">$2M+</p>
            <p>Paid to Workers</p>
          </div>
        </div>
      </div>
    </div>
  );
}
